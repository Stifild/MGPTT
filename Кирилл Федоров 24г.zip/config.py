DB_NAME = ".\data\database.db"
DB_TABLE_USERS_NAME = "users"
MODEL_NAME = "rhysjones/phi-2-orange"
LOGS_PATH = ".\data\logs.txt"
GPT_URL = "http://158.160.135.104:1234/v1/chat/completions"
MAX_ONTASK_TOKENS = 50
ADMIN_LIST = [6303315695]
TEMPERATURE = 0.7